

# BDD

[![Hecho por Chaska](https://img.shields.io/badge/hecho_por-Ch'aska-303030.svg)](https://cajadeideas.ar)
[![Versión: 0.7.10](https://img.shields.io/badge/version-v0.5.2-green.svg)](https://github.com/hernanatn/github.com/hernanatn/bdd.py/releases/latest)
[![Verisón de Python: 3.12](https://img.shields.io/badge/Python-3.12-blue?logo=python)](https://www.python.org/downloads/release/python-3120/)
[![Licencia: MIT](https://img.shields.io/badge/Licencia-MIT-lightgrey.svg)](LICENSE)


## Descripción
Módulo de Python 3.x con abstracciones útiles para gestión de Bases de Datos y construcción de modelos.

## [Documentación](/docs)
