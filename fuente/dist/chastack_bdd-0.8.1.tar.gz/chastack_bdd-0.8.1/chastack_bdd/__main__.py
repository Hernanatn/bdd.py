


#  HACER: Generar las clases que heredan de Tabla (y TablaIntermedia)
#  HACER: como un módulo estático sin cosas en tiempo de ejecución



def main() -> None:
    return

if __name__ == "__main__":
    main()